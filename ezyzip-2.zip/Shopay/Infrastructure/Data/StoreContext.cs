
using System.Reflection;
using Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Data
{
    public class StoreContext : DbContext     //after installing nuget package manager for entityframework for sqlite
    {
        public StoreContext(DbContextOptions<StoreContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }         //property where we create a database of products
        public DbSet<ProductType> ProductTypes { get; set; }     //database of product types
        public DbSet<ProductBrand> ProductBrands { get; set; }    //database of product brands
        public DbSet<Category> Categories { get; set; }    //database of product category

        protected override void OnModelCreating(ModelBuilder modelBuilder)   //method
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

        if (Database.ProviderName == "Microsoft.EntityFrameworkCore.Sqlite")    //condition for decimal price demerit of sqlite
        {
            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
            {
                var properties = entityType.ClrType.GetProperties().Where(p => p.PropertyType == typeof(decimal));

                foreach (var property in properties)
                {
                    modelBuilder.Entity(entityType.Name).Property(property.Name).HasConversion<double>();
                }
            }
        }

        }
    }
}