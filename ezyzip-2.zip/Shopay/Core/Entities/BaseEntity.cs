namespace Core.Entities
{
    public class BaseEntity
    {
        public int Id { get; set; }      //property to fetch details into database
    }
}